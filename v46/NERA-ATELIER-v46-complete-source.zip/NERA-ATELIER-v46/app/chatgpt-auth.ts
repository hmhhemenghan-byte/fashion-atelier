import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { createRemoteJWKSet, jwtVerify, type JWTPayload } from "jose";
import { getAuthRuntimeConfig } from "@/lib/runtime";

export type ChatGPTUser = {
  displayName: string;
  email: string;
  fullName: string | null;
};

const USER_EMAIL_HEADER = "oai-authenticated-user-email";
const USER_FULL_NAME_HEADER = "oai-authenticated-user-full-name";
const USER_FULL_NAME_ENCODING_HEADER =
  "oai-authenticated-user-full-name-encoding";
const PERCENT_ENCODED_UTF8 = "percent-encoded-utf-8";
const SIGN_IN_PATH = "/signin-with-chatgpt";
const SIGN_OUT_PATH = "/signout-with-chatgpt";
const CALLBACK_PATH = "/callback";
const ACCESS_ASSERTION_HEADER = "cf-access-jwt-assertion";
const accessKeySets = new Map<string, ReturnType<typeof createRemoteJWKSet>>();

export async function getChatGPTUser(): Promise<ChatGPTUser | null> {
  const auth = await getAuthRuntimeConfig();
  const requestHeaders = await headers();
  if (auth.provider === "cloudflare-access") {
    return getCloudflareAccessUser(
      requestHeaders.get(ACCESS_ASSERTION_HEADER),
      auth.teamDomain,
      auth.policyAudience,
    );
  }

  const email = requestHeaders.get(USER_EMAIL_HEADER);
  if (!email) return null;

  const encodedFullName = requestHeaders.get(USER_FULL_NAME_HEADER);
  const fullName =
    encodedFullName &&
    requestHeaders.get(USER_FULL_NAME_ENCODING_HEADER) === PERCENT_ENCODED_UTF8
      ? safeDecodeURIComponent(encodedFullName)
      : null;

  return {
    displayName: fullName ?? email,
    email,
    fullName,
  };
}

export async function requireChatGPTUser(
  returnTo: string,
): Promise<ChatGPTUser> {
  const user = await getChatGPTUser();
  if (user) return user;

  redirect(await chatGPTSignInPath(returnTo));
}

export async function chatGPTSignInPath(returnTo: string): Promise<string> {
  if ((await getAuthRuntimeConfig()).provider === "cloudflare-access") {
    // Access should intercept this request before it reaches the Worker. If it
    // does not, fail closed instead of inventing an unverified login URL.
    return "/";
  }
  const safeReturnTo = safeRelativeReturnPath(returnTo);
  return `${SIGN_IN_PATH}?return_to=${encodeURIComponent(safeReturnTo)}`;
}

export async function chatGPTSignOutPath(returnTo = "/"): Promise<string> {
  if ((await getAuthRuntimeConfig()).provider === "cloudflare-access") {
    return "/cdn-cgi/access/logout";
  }
  const safeReturnTo = safeRelativeReturnPath(returnTo);
  return `${SIGN_OUT_PATH}?return_to=${encodeURIComponent(safeReturnTo)}`;
}

async function getCloudflareAccessUser(
  assertion: string | null,
  rawTeamDomain: string | null,
  audience: string | null,
): Promise<ChatGPTUser | null> {
  if (!assertion || !rawTeamDomain || !audience) return null;

  const teamDomain = normalizeTeamDomain(rawTeamDomain);
  if (!teamDomain) return null;

  try {
    let keySet = accessKeySets.get(teamDomain);
    if (!keySet) {
      keySet = createRemoteJWKSet(
        new URL(`${teamDomain}/cdn-cgi/access/certs`),
      );
      accessKeySets.set(teamDomain, keySet);
    }

    const { payload } = await jwtVerify(assertion, keySet, {
      audience,
      issuer: teamDomain,
    });
    return userFromAccessPayload(payload);
  } catch {
    return null;
  }
}

function userFromAccessPayload(payload: JWTPayload): ChatGPTUser | null {
  if (typeof payload.email !== "string" || !payload.email.trim()) return null;

  const email = payload.email.trim();
  const fullName =
    typeof payload.name === "string" && payload.name.trim()
      ? payload.name.trim()
      : null;
  return { displayName: fullName ?? email, email, fullName };
}

function normalizeTeamDomain(value: string): string | null {
  try {
    const url = new URL(value);
    if (
      url.protocol !== "https:" ||
      !url.hostname.endsWith(".cloudflareaccess.com") ||
      url.pathname !== "/" ||
      url.search ||
      url.hash
    ) {
      return null;
    }
    return url.origin;
  } catch {
    return null;
  }
}

function safeRelativeReturnPath(value: string): string {
  if (!value.startsWith("/") || value.startsWith("//")) return "/";

  let url: URL;
  try {
    url = new URL(value, "https://app.local");
  } catch {
    return "/";
  }
  if (url.origin !== "https://app.local") return "/";
  if (isReservedAuthPath(url.pathname)) return "/";

  return `${url.pathname}${url.search}${url.hash}`;
}

function isReservedAuthPath(pathname: string): boolean {
  return (
    pathname === SIGN_IN_PATH ||
    pathname === SIGN_OUT_PATH ||
    pathname === CALLBACK_PATH
  );
}

function safeDecodeURIComponent(value: string): string | null {
  try {
    return decodeURIComponent(value);
  } catch {
    return null;
  }
}
